Overview
This README provides an outline of the steps taken to filter and process the initial dataset obtained from the NYSDOT portal. The final result is an Excel file containing contract information with exactly one BIN (Bridge Identification Number) for each contract.

Data Source
Original Data: The data consists of folders of project records (PDF or TIFF files) downloaded from the New York State Department of Transportation (NYSDOT) Portal. Each folder is named by a unique contract number.
Purpose: The objective was to isolate contracts with exactly one BIN to streamline further analysis.

Data Download and Organization
Data Download:

The data was downloaded from the NYSDOT portal, which provides public access to project records. 
The data was manually downloaded and saved on a D drive, with each folder organized by contract number.

Unzipping Folders Using Cygwin:

The downloaded data files were in ZIP format. Each ZIP file corresponds to a specific contract number and contains PDF or TIFF files related to that project.
Cygwin was used to automate the unzipping process on a Windows system, providing a Unix-like command-line interface.
The unzip command was used in Cygwin to extract each ZIP file into a folder named by its contract number.
These unzipped folders were saved in a main directory on the D drive.

Initial Contract Information Excel File:

After unzipping the folders, an Excel file was available that contained additional details about each contract, including:
Contract Number: Unique identifier for each project.
Date of Contract: The date associated with each contract.
BINs: Bridge Identification Numbers associated with each contract.
Additional columns with further contract details, as provided in the original dataset.

Data Filtering and Final Output
Filtering for Single BIN Contracts:

A Python script was used to filter the data based on the BIN column in the Excel file, retaining only rows where the BINs column contained exactly one BIN.
This filtering process created a subset of the original data, focusing only on contracts that have a single BIN for uniformity in further analysis.

Final Output:

The filtered data was saved in an Excel file named Contracts_with_one_BIN.xlsx, containing:
Contract Number: Unique identifier for each contract.
Date of Contract: The date associated with each project.
BIN: The single BIN associated with each selected contract.