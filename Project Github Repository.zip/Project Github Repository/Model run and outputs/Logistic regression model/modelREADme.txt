# Logistic Regression Model Training Workflow

## Overview
This document explains the workflow for training the logistic regression model to assess the impact of resolution, noise level, and contract date on BIN extraction accuracy. It includes details about the inputs, outputs, and key steps of the code.

---

## Project Structure

Project Directory/
├── Filtered_Scaled_Data_with_Original_Values.xlsx
├── Model_Training_Code.py
├── Extraction_Accuracy.xlsx
├── Outputs/
│   ├── Confusion_Matrix.png
│   ├── Classification_Report.txt
│   └── Model_Accuracy.txt


---

## Workflow Steps

### 1. **Input Files**
   - **`Filtered_Scaled_Data_with_Original_Values.xlsx`**: This file contains the dataset with scaled and original values of predictors:
     - Resolution (DPI)
     - Noise Level (%)
     - Contract Date (as a numeric value).
     - Extraction Accuracy (target variable: 0 or 1).

   - **Location**: `C:\Users\bkkeushk\OneDrive - Syracuse University\Desktop\PhD courses\CEE 609 Env Data Science\project\Linear regression model`

### 2. **Model Training**
   - The Python script **`Model_Training_Code.py`** includes:
     - Reading the input Excel file.
     - Splitting the data into training (70%) and testing (30%) sets.
     - Training the logistic regression model.
     - Evaluating the model using:
       - Accuracy score.
       - Confusion matrix.
       - Classification report.

### 3. **Outputs**
   - **Confusion Matrix**: Visualization of true positives, false positives, true negatives, and false negatives.
     - Saved as: `Confusion_Matrix.png` in the `Outputs/` folder.
   - **Classification Report**: Detailed metrics (precision, recall, f1-score).
     - Saved as: `Classification_Report.txt` in the `Outputs/` folder.
   - **Model Accuracy**: Overall accuracy of the logistic regression model.
     - Saved as: `Model_Accuracy.txt` in the `Outputs/` folder.

---

## How to Run

1. Ensure all dependencies are installed:
   - `pandas`
   - `numpy`
   - `scikit-learn`
   - `matplotlib`

2. Place the input file (`Filtered_Scaled_Data_with_Original_Values.xlsx`) in the root project directory.

3. Run the training script:
   ```bash
   python Model_Training_Code.py
